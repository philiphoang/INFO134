// JavaScript Document

function makeReveal(elt) {
    var title = elt.getElementsByClassName("handle")[0];
    // When that element is clicked, reveal the rest of the content
    title.onclick = function () {
        if (elt.className == "reveal") {
            elt.className = "revealed";
        } else if (elt.className == "revealed") {
            elt.className = "reveal";
        }
    };
}

/** Vi lager et nytt variabel ved navn 'arrayClassReveal' som viser til en array med alle elementer på html siden vår som har klassen 'reveal'. 

    Vi benytter oss av metoden 'getElementsByClassName' på html dokumentet vårt som returnerer en array. Vi må derfor alltid bruke bracket notasjon for å vise til hvert enkelt objekt som for eksempel slik: 'document.getElementsByClassName("reveal")[0]'. Dette vil gi oss det første elementet som forekommer fra top til bunn i html dokumentet. 
*/
var arrayClassReveal = document.getElementsByClassName("reveal");

/** Vi kjører så funksjonen vår på alle elementer som har klassen 'reveal' ved hjelp av en 'for-loop'. 
    Dette er mest for å forsikre oss om at alle elementer har den oppførselen som forventes om det skulle eksistere flere enn ett 'reveal' element.
*/
for(var i = 0; i < arrayClassReveal.length; i++) {
    makeReveal(arrayClassReveal[i]);
}

// Alternativt bare:
//
// makeReveal(arrayClassReveal[0]);
// makeReveal(document.getElementsByClassName("reveal")[0]);